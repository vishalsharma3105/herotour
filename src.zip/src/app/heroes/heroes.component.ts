import { Component, OnInit } from '@angular/core';
import {Hero} from './hero'
import {mockHeroes} from './hero-mock'
@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {

  heroes =  mockHeroes;
  selectedHero : Hero;

 
  constructor() { }

  ngOnInit() {
  }
  
  onSelect(hero:Hero) : void {
    this.selectedHero = hero;
}
 
}

